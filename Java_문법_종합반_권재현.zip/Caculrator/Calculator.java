package Caculrator;

import Caculrator.Operation.AbstractOperation;

public class Calculator {

    private AbstractOperation operation;

    public Calculator(AbstractOperation operation){
        this.operation = operation;
    }

    public void setOperation(AbstractOperation operation){
        this.operation = operation;
    }

    public double calculate(int FirstNumber, int SecondNumber){
        double result = 0.0;
        result = operation.operate(FirstNumber, SecondNumber);
        return result;
    }
}
