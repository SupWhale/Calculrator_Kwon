package Caculrator;

import Caculrator.Operation.AddOperation;
import Caculrator.Operation.DivideOperation;
import Caculrator.Operation.MultiplyOperation;
import Caculrator.Operation.SubstractOperation;

public class Main {
    public static void main(String[] args) {
        Calculator calculator  = new Calculator(new AddOperation());
        System.out.println(calculator.calculate(10, 20));

        calculator.setOperation(new MultiplyOperation());
        System.out.println(calculator.calculate(10,20));

        calculator.setOperation(new SubstractOperation());
        System.out.println(calculator.calculate(10,20));

        calculator.setOperation(new DivideOperation());
        System.out.println(calculator.calculate(10,20));
    }
}