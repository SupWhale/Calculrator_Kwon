package Caculrator.Operation;

public abstract class AbstractOperation {
    public abstract double operate(int firstNumber, int secondNumber);
}
